/*
 * rtwtypes.h
 *
 * Code generation for function 'BilateralFilter'
 *
 */

#pragma once

#include "tmwtypes.h"

/*
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE                           (1U)
#endif

#ifndef FALSE
#define FALSE                          (0U)
#endif

/* End of code generation (rtwtypes.h) */
