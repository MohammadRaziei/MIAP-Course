/*
 * BilateralFilter_types.h
 *
 * Code generation for function 'BilateralFilter_types'
 *
 */

#pragma once

/* Include files */
#include "rtwtypes.h"

/* Type Definitions */
struct emxArray_real32_T
{
  real32_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

/* End of code generation (BilateralFilter_types.h) */
