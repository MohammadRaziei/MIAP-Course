/*
 * BilateralFilter_terminate.h
 *
 * Code generation for function 'BilateralFilter_terminate'
 *
 */

#pragma once

/* Include files */
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "BilateralFilter_types.h"

/* Function Declarations */
CODEGEN_EXPORT_SYM void BilateralFilter_atexit();
CODEGEN_EXPORT_SYM void BilateralFilter_terminate();

/* End of code generation (BilateralFilter_terminate.h) */
