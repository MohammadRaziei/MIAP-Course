/*
 * BilateralFilter_data.h
 *
 * Code generation for function 'BilateralFilter_data'
 *
 */

#pragma once

/* Include files */
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "BilateralFilter_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* End of code generation (BilateralFilter_data.h) */
