/*
 * BilateralFilter_emxutil.h
 *
 * Code generation for function 'BilateralFilter_emxutil'
 *
 */

#pragma once

/* Include files */
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "BilateralFilter_types.h"

/* Function Declarations */
CODEGEN_EXPORT_SYM void emxEnsureCapacity_real32_T(emxArray_real32_T *emxArray,
  int32_T oldNumel);
CODEGEN_EXPORT_SYM void emxFree_real32_T(emxArray_real32_T **pEmxArray);
CODEGEN_EXPORT_SYM void emxInit_real32_T(emxArray_real32_T **pEmxArray, int32_T
  numDimensions, boolean_T doPush);

/* End of code generation (BilateralFilter_emxutil.h) */
