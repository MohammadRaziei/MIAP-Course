/*
 * _coder_BilateralFilter_api.h
 *
 * Code generation for function '_coder_BilateralFilter_api'
 *
 */

#pragma once

/* Include files */
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "BilateralFilter_types.h"

/* Function Declarations */
void BilateralFilter_api(const mxArray * const prhs[3], int32_T nlhs, const
  mxArray *plhs[1]);

/* End of code generation (_coder_BilateralFilter_api.h) */
