/*
 * _coder_BilateralFilter_info.h
 *
 * Code generation for function '_coder_BilateralFilter_info'
 *
 */

#pragma once

/* Include files */
#include "mex.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

/* End of code generation (_coder_BilateralFilter_info.h) */
